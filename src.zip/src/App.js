/**-----------------------------------------------------------*
 *                  SENAC - TADS - PROGRAMAÇÃO WEB            *
 *       ADO#02      TRABALHANDO AS ROTAS E LINKS             *
 * -----------------------------------------------------------*
 *         NOME : CARLOS HENRIQUE NASCIMENTO DOS SANTOS       * 
 *------------------------------------------------------------*
 */
import RoutesApp from "./routes";

function App() {
  return (
    <RoutesApp/>

  )
};

export default App;
