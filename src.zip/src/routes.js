import { BrowserRouter,Routes,Route } from "react-router-dom";
import Home from './pages/Home'
import Cadastro from './pages/Cadastro'
import Conta from "./pages/ContaCorrente";
import Financeiro from "./pages/Financeiro";
import Sobre from "./pages/Sobre";


function RoutesApp (){
    return(
    <BrowserRouter>
    <Routes>
        <Route path='/' element={<Home/>}/>
        <Route path='/cadastro' element= {<Cadastro/>}/>
        <Route path='/conta' element= {<Conta/>}/>
        <Route path='/financeiro' element= {<Financeiro/>}/>
        <Route path='/sobre' element= {<Sobre/>}/>
 
    </Routes>
    </BrowserRouter>
    )
};
export default RoutesApp;