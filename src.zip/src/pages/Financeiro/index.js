function Financeiro (){
    return (
        <div>
            <h1>FINANCEIRO</h1>
            <h2>Valor Solicitado :</h2>
            <button>Calcular Financiamento :</button>

        </div>
    )
};

export default Financeiro ;