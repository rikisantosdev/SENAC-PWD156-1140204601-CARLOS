function Cadastro (){
    return (
        <div>
            <h1> CADASTRO DO CLIENTE</h1>
            <h2>Nome :_______________________</h2>
            <h2>Endereço:____________________</h2>
            <h2>CPF:__________________________</h2>

            
        </div>
    )
};

export default Cadastro;