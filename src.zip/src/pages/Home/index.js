import {Link} from 'react-router-dom';

function Home (){
    return (
        <div>
            <h1>Página Home</h1>
            <br></br>
            <Link to = '/'>Home</Link><br/>
            <Link to = '/cadastro'>Cadastro</Link><br/>
            <Link to = '/conta'>Conta</Link><br/>
            <Link to = '/financeiro'>Financeiro</Link><br/>
            <Link to = '/sobre'>Sobre</Link><br/>
        </div>
    )
};

export default Home;