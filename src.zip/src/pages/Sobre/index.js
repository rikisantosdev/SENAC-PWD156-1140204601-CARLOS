function Sobre (){
    return (
        <div>
            <h1>Sobre Nós</h1>
           <h3>A empresa tem como objetivo ...</h3>
        </div>
    )
};

export default Sobre;