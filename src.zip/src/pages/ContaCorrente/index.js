function Conta (){
    return (
        <div>
            <h1>CONTA CORRENTE</h1>
            <h2>Depósito :______________________</h2>
            <h2>Saque:</h2>
            <button>Atualizar Saldo</button>
        </div>
    )
};

export default Conta;